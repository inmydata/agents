ConditionOperator
========================

.. autoclass:: inmydata.StructuredData.ConditionOperator
   :members:
   :undoc-members:
   :show-inheritance:
   :no-index:
   :special-members: __init__