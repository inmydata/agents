AIDataSimpleFilter
==================

.. autoclass:: inmydata.StructuredData.AIDataSimpleFilter
   :members:
   :undoc-members:
   :show-inheritance:
   :no-index:
   :special-members: __init__
   
