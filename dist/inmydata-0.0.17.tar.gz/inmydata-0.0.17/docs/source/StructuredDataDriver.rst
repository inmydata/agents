StructuredDataDriver
====================

.. autoclass:: inmydata.StructuredData.StructuredDataDriver
   :members:
   :undoc-members:
   :show-inheritance:
   :no-index:
   :special-members: __init__