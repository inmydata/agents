ChartType
=========

.. autoclass:: inmydata.StructuredData.ChartType
    :members:
    :undoc-members:
    :show-inheritance:
    :no-index: